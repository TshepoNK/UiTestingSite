<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>New Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>103a3ead-0617-4521-be56-5f74ab56e094</testSuiteGuid>
   <testCaseLink>
      <guid>979bff83-8ea7-4ac5-97d9-70de01e89535</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/RunFeatureFile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ac11672b-58d0-48a4-b979-e9dee2176bc6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestUI</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
